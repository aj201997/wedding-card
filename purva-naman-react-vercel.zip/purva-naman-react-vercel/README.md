# Purva & Naman — Wedding Invitation

A mobile-first, animated wedding invitation built with React and Vite. It is a static frontend and does not require a backend or environment variables.

## What is included

- Animated envelope opening and original inline SVG bride-and-groom illustrations
- Responsive sections for the couple, both wedding days, family, venue, and finale
- Live countdown to the wedding date
- Scroll-reveal animations, floating petals/confetti, animated baraat illustration
- Working Google Maps link using the location URL from the supplied invitation
- Click-to-call RSVP phone numbers
- Native share sheet on supported phones, with clipboard fallback
- Reduced-motion support and mobile-friendly navigation
- Vercel configuration (`vercel.json`)

## Run locally

Requires Node.js 18 or newer.

```bash
npm install
npm run dev
```

Open the local URL printed by Vite (usually `http://localhost:5173`).

To make a production build locally:

```bash
npm run build
npm run preview
```

## Deploy on Vercel

### Option A — GitHub (recommended)

1. Create a new GitHub repository.
2. Upload/commit the contents of this folder to the repository root. Do not upload the ZIP file itself as the repository's only file; extract it first.
3. In Vercel, choose **Add New → Project**, import the repository, and deploy.
4. Vercel detects Vite. The configuration in `vercel.json` sets:
   - Build command: `npm run build`
   - Output directory: `dist`
5. After deployment, copy the public `*.vercel.app` URL and share it with the guests.

### Option B — Vercel CLI

```bash
npm install
npx vercel
```

Follow the prompts. To deploy to production after the first setup:

```bash
npx vercel --prod
```

## Customising the invite

The couple names, dates, event information, family names and RSVP details live in `src/App.jsx`. The map URL is the `MAP_URL` constant near the top of that file. The theme, typography and responsive behaviour are in `src/styles.css`.

The invitation contains the original venue Google Maps link:
`https://maps.app.goo.gl/vs6nQKWr71HYymzv9`

## Notes

- This is a frontend invitation: RSVP phone numbers open the guest's phone app. There is no database-backed RSVP collection.
- The countdown targets the wedding evening, 12 December 2026 at 8:00 PM India Standard Time.
- Google Fonts are loaded remotely for typography; system fallbacks are provided.
